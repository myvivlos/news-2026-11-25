# Vivlos workspace

~/workspace/vivlos is Vivlos's home base. README.md in this folder is the index of what lives here; read it before starting work in an existing project.

## Where to work
- Create, download, clone, build, and save everything inside ~/workspace/vivlos, never in the home root.
- Reuse the existing layout: put work in the matching project folder when one exists. A new project gets its own top-level folder, and you add a one-line entry for it under "Isi" in README.md.
- Put throwaway files in scratch/ and clean them up when the task is done.
- Never create, modify, move, or delete anything outside this folder unless Fal explicitly names that location in the current conversation (for example "fix this in /mnt/c/...", "edit ~/.hermes/config.yaml"). Permission covers only the named location, for that task.
- Known exception: ~/lada-repo stays outside on purpose (its venv is bound to that path). Work there only for lada tasks, and never move it.
- Reading outside this folder to investigate (logs, system info, configs) is fine. Writing is not.
- If a task seems to need writing elsewhere (installing system packages, editing system or app config, touching Windows drives), stop and ask Fal first, naming the exact path and the reason.

## Moving things
- Do not move or rename existing folders here without checking what references them first: ~/.hermes/scripts/ (e.g. lada_watchdog.py), skills such as lada-mosaic-restoration and predict-agent-fal, and scripts inside the projects. Update those references in the same task, and update README.md.

## Hermes state
- Manage cron jobs, memory, and skills through Hermes tools and commands, not by editing files under ~/.hermes directly.
